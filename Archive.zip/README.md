# Personal Blocklist

Remove search results you don't want to see!

This Add-on is partially forked from `Personal Blocklist (By Google)`.

## Dev

```
npm i -g web-ext
npm run dev
npm run watch
```

## Build

```
yarn install
yarn build
cd build
web-ext build
```
